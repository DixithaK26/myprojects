const clock=document.getElementsByClassName("clock")[0]

function updateClock() {

    const update=new Date();
     let hours=update.getHours();
     let minutes=update.getMinutes();
    let seconds=update.getSeconds();

    //am and pm
    const dan=hours>=12?"PM":"AM"
     hours=hours%12||12;

     hours=hours<10?"0"+ hours:hours
     minutes=minutes<10?"0"+ minutes:minutes
      seconds=seconds<10?"0"+ seconds:seconds


      clock.textContent=`${hours}:${minutes}:${seconds} ${dan}`;
  
}

setInterval(updateClock,1000);
updateClock();