
const loginButton = document.querySelector(".butn");
const loginPage = document.querySelector(".page");
const closeIcon = document.querySelector(".fa-xmark");

loginButton.addEventListener("click", () => {
  loginPage.style.display = "block";
});

closeIcon.addEventListener("click", () => {
  loginPage.style.display = "none";
});


window.addEventListener("click", (e) => {
  if (e.target === loginPage) {
    loginPage.style.display = "none";
  }
});


const menuToggle = document.getElementById("cb");
const navList = document.querySelector(".navigation ul");

menuToggle.addEventListener("change", () => {
  if (menuToggle.checked) {
    navList.style.display = "flex";
  } else {
    navList.style.display = "none";
  }
});
